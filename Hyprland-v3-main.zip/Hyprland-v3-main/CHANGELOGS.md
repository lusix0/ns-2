## Changelogs

## 27-Sep-2023
- remove auto start of portal-hyprland-hyprland
- removal of Virtual-1 monitor in Monitors.conf

### 25 Sep 2023
- added nvidia-grub users function to add nvidia_drm.modeset=1 in /etc/default/grub

### 24 Aug, 2023
- added wlsunset. Thanks to @yamanmucahit. Disabled by default. Edit ~/.config/hypr/config/Execs.conf if wanted
  
### 18 Aug, 2023
- added nvtop (right click on cpu temp on waybar)

### 16 Aug, 2023
- replaced waybar-hyprland-git with waybar in install script
- added emoji selector (super alt E)
- added quick configs edit using nano (super E)
  
### 15 Aug, 2023
- added AppAutoClose.sh. Script to add process to automatically close when not active. Thanks to @U-L-M-S

### 12 Aug, 2023
- cleanup hyprland.conf
- updated Changelayout script

### Jul 12, 2023
- disabled clickfinger_behaviour on hyprland.conf to fix the bottom right click on touchpad

### June 26, 2023
- added swappy, and cliphist (clipboard manager)

### June 24, 2023
- switched MacOS style installs to binary
